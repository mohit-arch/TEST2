import UIKit
import Foundation

import Foundation

struct Weather: Codable {
    let location: Location?
    let current: Current?
    let forecast: Forecast?
}

struct Location: Codable {
    let name: String
}

struct Current: Codable {
    let temp_c: Double
    let humidity: Double
    let wind_kph: Double
}

struct Forecast: Codable {
    let forecastday: [ForecastDay]
}

struct ForecastDay: Codable {
    let date: String
    let day: Day
}

struct Day: Codable {
    let maxtemp_c: Double
    let maxwind_kph: Double
    let mintemp_c: Double
    let condition: Condition
    let avghumidity: Double
}

struct Condition: Codable {
    let text: String
}

class HomeViewController: UIViewController {

    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var windSpeedLabel: UILabel!
    
    var weather: Weather?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        fetchWeatherData(city: "London")
    }

    func fetchWeatherData(city: String) {
        WeatherService.shared.fetchWeatherData(for: city) { [weak self] result in
            switch result {
            case .success(let weatherData):
                DispatchQueue.main.async {
                    self?.updateUI(with: weatherData)
                }
            case .failure(let error):
                print("Error fetching weather data: \(error)")
            }
        }
    }

    func updateUI(with weatherData: Weather) {
        self.weather = weatherData
        locationLabel.text = weatherData.location?.name
        temperatureLabel.text = "\(weatherData.current?.temp_c)°C"
        humidityLabel.text = "Humidity: \(weatherData.current?.humidity)%"
        windSpeedLabel.text = "Wind Speed: \(weatherData.current?.wind_kph) km/h"
    }
    
    @IBAction func btnShowDataAction(_ sender: UIButton) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "WeatherDetailsVC") as! WeatherDetailsVC
        vc.weather = self.weather
        navigationController?.pushViewController(vc, animated: true)
    }
}
