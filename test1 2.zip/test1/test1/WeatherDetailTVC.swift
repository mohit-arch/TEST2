
import UIKit

class WeatherDetailTVC: UITableViewCell {

    @IBOutlet weak var lblDay: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblWindSpeed: UILabel!
    @IBOutlet weak var lblTempreture: UILabel!
    @IBOutlet weak var lblHumdity: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func showData(day: Int, weatherData: Day?, location: String?) {
        if let weatherData = weatherData, let location = location {
            lblDay.text = "Day \(day)"
            lblLocation.text = location
            lblTempreture.text = "\(weatherData.maxtemp_c)°C"
            lblHumdity.text = "Humidity: \(weatherData.avghumidity)%"
            lblWindSpeed.text = "Wind Speed: \(weatherData.maxwind_kph) km/h"
        }
    }
}
