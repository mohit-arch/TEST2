import UIKit

class WeatherDetailsVC: UIViewController {

    @IBOutlet weak var tblvw: UITableView!
    
    var weather: Weather?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

extension WeatherDetailsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        weather?.forecast?.forecastday.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WeatherDetailTVC", for: indexPath) as! WeatherDetailTVC
        cell.showData(day: indexPath.row + 1, weatherData: weather?.forecast?.forecastday[indexPath.row].day, location: weather?.location?.name)
        return cell
    }
    
    
}
