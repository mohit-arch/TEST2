import Foundation

class WeatherService {
    static let shared = WeatherService()
    
    private init() {}
    
    func fetchWeatherData(for city: String, completion: @escaping (Result<Weather, Error>) -> Void) {
        let apiKey = "b3d08128c1ae4356a9c103636230611"
        let urlString = "https://api.weatherapi.com/v1/forecast.json?key=\(apiKey)&q=\(city)&days=3"
        
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let error = error {
                    completion(.failure(error))
                    return
                }
                
                if let data = data {
                    do {
                        let anyValue = try? JSONSerialization.jsonObject(with: data)
                        debugPrint(anyValue as? NSDictionary)
                        let decoder = JSONDecoder()
                        let weatherData = try decoder.decode(Weather.self, from: data)
                        completion(.success(weatherData))
                    } catch {
                        completion(.failure(error))
                    }
                }
            }.resume()
        }
    }
}
