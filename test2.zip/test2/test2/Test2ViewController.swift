import UIKit

class Test2ViewController: UIViewController {
    var passenger:Int = 0
    var selectedPrice = 0
    var charges:Double = 0
    @IBOutlet weak var paylbl: UILabel!
    @IBOutlet weak var payBtn: UIButton!{
        didSet{
            payBtn.layer.cornerRadius = 8
        }
    }

    @IBOutlet weak var passengerBtn: UIButton!{ didSet{
        passengerBtn.isUserInteractionEnabled = false
        passengerBtn.layer.borderWidth = 1
        passengerBtn.layer.borderColor = UIColor(red: 0.949, green: 0.949, blue: 0.949, alpha: 1).cgColor
        
        passengerBtn.layer.cornerRadius = 6
    }
    }
    @IBOutlet weak var price5: UIButton!{
        didSet{
            price5.layer.borderWidth = 1
            price5.layer.borderColor = UIColor(red: 0.949, green: 0.949, blue: 0.949, alpha: 1).cgColor
            
            price5.layer.cornerRadius = 6
        }
    }
    @IBOutlet weak var price10: UIButton!{
        didSet{
            price10.layer.borderWidth = 1
            price10.layer.borderColor = UIColor(red: 0.949, green: 0.949, blue: 0.949, alpha: 1).cgColor
            price10.layer.cornerRadius = 6
        }
    }
    @IBOutlet weak var discount: UILabel!{
        didSet{
            if passenger > 1{
                discount.isHidden = false
            }
            else{
                discount.isHidden = true
            }
        }
    }
    @IBOutlet weak var price15: UIButton!{
        didSet{
            price15.layer.borderWidth = 1
            price15.layer.borderColor = UIColor(red: 0.949, green: 0.949, blue: 0.949, alpha: 1).cgColor
            price15.layer.cornerRadius = 6
        }
    }
    @IBOutlet weak var selectFareBtn: UIButton!{
        didSet{
            selectFareBtn.layer.cornerRadius = 8
        }
    }
    @IBOutlet weak var selectDetinationBtn: UIButton!{
        didSet{
            selectDetinationBtn.layer.borderColor = UIColor.gray.cgColor
            selectDetinationBtn.layer.borderWidth = 1
            selectDetinationBtn.layer.cornerRadius = 8
            
        }
    }
    @IBOutlet weak var startingNameLbl: UILabel!{
        didSet{
            startingNameLbl.textColor = UIColor(red: 0.098, green: 0.098, blue: 0.098, alpha: 1)
            
            startingNameLbl.text = "Inderlok Metro Station"
        }
    }
    @IBOutlet weak var startingLbl: UILabel!{
        didSet{
            startingLbl.textColor = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1)
            startingLbl.text = "Starting"
        }
    }
    @IBOutlet weak var dashedView: UIView!
    @IBOutlet weak var busImageView: UIImageView!{ didSet{
        busImageView.layer.cornerRadius = busImageView.frame.height/2
    }
    }
    @IBOutlet weak var towardsLbl: UILabel!{
        didSet{
            
            towardsLbl.textColor = UIColor(red: 0.098, green: 0.098, blue: 0.098, alpha: 1)
            
            towardsLbl.text = "Madhu Vihar"
        }
    }
    @IBOutlet weak var goingLbl: UILabel!{
        didSet{
            goingLbl.textColor = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1)
            goingLbl.text = "Ending"
        }
    }
    @IBOutlet weak var routeNumberLbl: UILabel!{didSet{
        routeNumberLbl.textColor = UIColor(red: 0.098, green: 0.098, blue: 0.098, alpha: 1)
        routeNumberLbl.font = UIFont(name: "Inter-SemiBold", size: 16)
        routeNumberLbl.text = "778"
    }
        
    }
    @IBOutlet weak var route: UILabel!{
        didSet{
            route.textColor = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1)
            route.font = UIFont(name: "Inter-Regular", size: 12)
            route.text = "Towards nderlok Metro Station"

        }
    }
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var innerView: UIView!{
        didSet{
            innerView.layer.cornerRadius = 16
            innerView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        }
        
    }
    @IBOutlet weak var mainView: UIView!{
        didSet{
            
            mainView.layer.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1).cgColor
            mainView.layer.cornerRadius = 16
            mainView.layer.borderWidth = 1
            mainView.layer.borderColor = UIColor(red: 0.949, green: 0.949, blue: 0.949, alpha: 1).cgColor
            mainView.dropShadow()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let date = Date()
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        let str2 = " | \(hour) : \(minutes)"
        time.text = str2
        drawDottedLine(start: CGPoint(x: dashedView.bounds.minX, y: dashedView.bounds.minY), end: CGPoint(x: dashedView.bounds.maxX, y: dashedView.bounds.minY ), view: dashedView)
        passengerBtn.setTitle("\(passenger)", for: .normal)

    }
    
    @IBAction func minusBtnTapped(_ sender: Any) {
        if passenger > 0{
            passenger -= 1
            passengerBtn.setTitle("\(passenger)", for: .normal)
            passengerlimit()
        }
        else{
            let alert = UIAlertController(title: "Alert", message: "passenger no. is already zero", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "okay", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        SetPrice()
    }
    @IBAction func addVtnTapped(_ sender: Any) {
        if passenger < 3{
            passenger += 1
            passengerBtn.setTitle("\(passenger)", for: .normal)
                                  passengerlimit()
        }
        else{
            let alert = UIAlertController(title: "Alert", message: "cannot add more than 3 passengers", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "okay", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        SetPrice()
    }
    func passengerlimit(){
        
        if passenger > 1{
            discount.isHidden = false
        }
        else{
            discount.isHidden = true
        }
    }

    @IBAction func tenBtnTapped(_ sender: Any) {
        price10.setTitleColor(.white, for: .normal)
        price10.backgroundColor = UIColor(red: 0.106, green: 0.729, blue: 0.749, alpha: 1)
        price10.setTitleColor(.white, for: .normal)
        price10.backgroundColor = UIColor(red: 0.106, green: 0.729, blue: 0.749, alpha: 1)
        price15.setTitleColor(.black, for: .normal)
        price15.backgroundColor = UIColor.white
        price5.setTitleColor(.black, for: .normal)
        price5.backgroundColor = UIColor.white
        selectedPrice = 10
        towardsLbl.text = "Mayapuri Deposit"
        SetPrice()
        
    }
    @IBAction func fifeBtnTapped(_ sender: Any) {
        
            price5.setTitleColor(.white, for: .normal)
            price5.backgroundColor = UIColor(red: 0.106, green: 0.729, blue: 0.749, alpha: 1)
            
            price15.backgroundColor = UIColor.white
            price15.setTitleColor(.black, for: .normal)
            price10.backgroundColor = UIColor.white
            price10.setTitleColor(.black, for: .normal)
            selectedPrice = 5
        towardsLbl.text = "Moti Nagar"
        SetPrice()
    }
    @IBAction func fifteenBtnTapped(_ sender: Any) {
        price15.setTitleColor(.white, for: .normal)
        price15.backgroundColor = UIColor(red: 0.106, green: 0.729, blue: 0.749, alpha: 1)
        
        price5.backgroundColor = UIColor.white
        price5.setTitleColor(.black, for: .normal)
        price10.backgroundColor = UIColor.white
        price10.setTitleColor(.black, for: .normal)
        selectedPrice = 15
        towardsLbl.text = "Desu Colony Janak Puri"
        SetPrice()

    }
    func SetPrice(){
        if passenger < 1{
            charges = Double(selectedPrice * passenger)
            paylbl.text = "₹\(charges)"
            payBtn.setTitle(" Pay ₹\(charges)", for: .normal)
    }
        else
        {
            charges = Double((selectedPrice * passenger))
                             charges = charges -  (charges * 0.05)
            paylbl.text = " ₹\(charges)"
            payBtn.setTitle(" Pay ₹\(charges)", for: .normal)
        }
}
    
    @IBAction func payBtnTapped(_ sender: Any) {
        if passenger == 0{
        let alert = UIAlertController(title: "Alert", message: "please select the no. of passengers ", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "okay", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)}
        
    else
    {
        let alert = UIAlertController(title: "payment successfull", message: " paid for \(passenger) passengers at     price \(charges)", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "okay", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)}
        
    }
}
extension UIView {

    func dropShadow() {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.5
        layer.shadowOffset = CGSize(width: 0, height: 1)
        layer.shadowRadius = 1
//        layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
//        layer.shouldRasterize = true
//        layer.rasterizationScale = UIScreen.main.scale
    }
}
extension Test2ViewController{
    func drawDottedLine(start p0: CGPoint, end p1: CGPoint, view: UIView) {
        let shapeLayer = CAShapeLayer()
        shapeLayer.strokeColor = UIColor.lightGray.cgColor
        shapeLayer.lineWidth = 1
        shapeLayer.lineDashPattern = [7, 3] // 7 is the length of dash, 3 is length of the gap.

        let path = CGMutablePath()
        path.addLines(between: [p0, p1])
        shapeLayer.path = path
        view.layer.addSublayer(shapeLayer)
    }
}
