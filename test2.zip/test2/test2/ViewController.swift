import Foundation

class BusTicketingApp {
    // Default values
    var ticketPrice: Int?
    var passengerCount: Int = 1

    // Pricing Constants
    let basePrices: [Int: String] = [5: "Moti Nagar", 10: "Mayapuri Depot", 15: "Desu Colony Janak Puri"]
    let discountPercentage: Double = 0.05
    let maxPassengerCount: Int = 3

    // Function to select ticket price
    func selectTicketPrice(_ price: Int) {
        ticketPrice = price
    }

    // Function to update ending stop based on selected price
    func updateEndingStop() -> String? {
        guard let price = ticketPrice else {
            return nil
        }

        return basePrices[price]
    }

    // Function to calculate dynamic pricing based on passenger count
    func calculateDynamicPrice() -> Double {
        guard let price = ticketPrice else {
            return 0.0
        }

        var totalPrice = Double(price)

        if passengerCount > 1 && passengerCount <= maxPassengerCount {
            totalPrice -= totalPrice * discountPercentage
        }

        return totalPrice
    }

    // Function to display route details
    func displayRouteDetails() {
        guard let price = ticketPrice else {
            print("Warning: Please select a ticket price.")
            return
        }

        let endingStop = updateEndingStop() ?? "Unknown"
        let dynamicPrice = calculateDynamicPrice()

        let routeDetails = """
        Route Details:
        Bus Number: DL1PC9658
        Time: \(getCurrentTime())
        Starting Stop: Inderlok Metro Station
        Route Name: 778
        Going Towards: Madhu Vihar
        Ending Stop: \(endingStop)
        Passenger Count: \(passengerCount)
        Price: ₹\(dynamicPrice)
        """

        showAlert(title: "Route Details", message: routeDetails)
    }

    // Function to get current time
    func getCurrentTime() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        return dateFormatter.string(from: Date())
    }

    // Function to show alert
    func showAlert(title: String, message: String) {
        print("\n\(title)\n\(message)")
    }
}

//// Example Usage with Three Price Buttons
//let busApp = BusTicketingApp()
//
//// UI Implementation - Select Ticket Price
//busApp.selectTicketPrice(10)
//
//// Functional Implementation - Display Route Details
//busApp.displayRouteDetails()
